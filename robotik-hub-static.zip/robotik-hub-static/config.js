/**
 * KONFIGURASI SUPABASE
 * -----------------------------------------------------------
 * Isi dua nilai di bawah ini dengan milik project Supabase kamu.
 * Cara mendapatkannya: buka https://app.supabase.com -> pilih project
 * kamu -> menu "Project Settings" -> "API".
 *
 * - SUPABASE_URL   = nilai "Project URL"
 * - SUPABASE_ANON_KEY = nilai "anon public" key
 *
 * Aman untuk ditaruh di file publik/frontend — kunci "anon" memang
 * didesain untuk dipakai di browser, aksesnya dibatasi lewat aturan
 * Row Level Security (RLS) yang sudah diatur lewat supabase/schema.sql.
 * -----------------------------------------------------------
 */
const SUPABASE_URL = 'https://GANTI-DENGAN-PROJECT-KAMU.supabase.co';
const SUPABASE_ANON_KEY = 'GANTI-DENGAN-ANON-KEY-KAMU';

// Nama bucket storage untuk file & foto proyek (dibuat di langkah setup)
const STORAGE_BUCKET = 'project-files';
